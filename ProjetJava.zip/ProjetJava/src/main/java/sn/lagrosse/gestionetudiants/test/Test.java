/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sn.lagrosse.gestionetudiants.test;

import java.util.List;
import java.util.Scanner;
import sn.lagrosse.gestionetudiants.imp.EtudiantImp;
import sn.lagrosse.gestionetudiants.imp.GroupeImp;
import sn.lagrosse.gestionetudiants.imp.ProfesseurImp;
import sn.lagrosse.gestionetudiants.imp.StudentGroupImp;
import sn.lagrosse.gestionetudiants.model.Etudiants;
import sn.lagrosse.gestionetudiants.model.Groupe;
import sn.lagrosse.gestionetudiants.model.Professeur;
import sn.lagrosse.gestionetudiants.model.Studentgroup;

/**
 *
 * @author lenovo
 */
public class Test {
   public static void main(String [] args){
       EtudiantImp etudiantImp = new EtudiantImp();
       ProfesseurImp profesImp = new ProfesseurImp();
       GroupeImp groupImp = new GroupeImp();
       StudentGroupImp studentgroupImp = new StudentGroupImp ();
       boolean var = true ;
       
       while (var) {
           
       System.out.println("          **************************        PROJET   FINAL        ***********************"); 
       
       
       System.out.println("          **************************        MENU  DES  CHOIX  PRINCIPAUX        ***********************");
       
       System.out.println("          **************************        QUELLE GESTION SOUHAITEZ-VOUS OUVRIR?        ***********************");
       
       System.out.println("          A) GESTION DES ETUDIANTS   ");
       System.out.println("          B) GESTION DES PROFESSEURS   ");
       System.out.println("          C) GESTION DES GROUPES    ");
       System.out.println("          D) GESTION DES GROUPES ETUDIANTS   ");
       System.out.println("          E) QUITTER   ");
       
       
       System.out.println("  ENTREZ VOTRE CHOIX :   ");
       Scanner sc = new Scanner(System.in);
       
       int choix  = sc.nextInt();
       switch(choix)
       {
           case 1:
               
               boolean var1 = true ;
               
               while (var1) {
                   
               
               System.out.println("      *****************           **A)GESTION   DES  ETUDIANTS**         **********************");
               
               System.out.println("          A1)  AJOUTER UN ETUDIANT   ");
               System.out.println("          A2)  SUPPRIMER UN ETUDIANT   ");
               System.out.println("          A3)  MODIFIER UN ETUDIANT   ");
               System.out.println("          A4)  AFFICHER LA LISTE   ");
               System.out.println("          A5)  RETOURNER AU MENU   ");
               
               
               System.out.println("        ENTREZ  VOTRE  CHOIX  : ");
       
               int choixEtudiant  = sc.nextInt();
               switch(choixEtudiant)
               {
                   case 1:
                       
                       
                       System.out.println("      *******  A1) AJOUTER UN ETUDIANT *******   ");
                       
                       System.out.println("  VEUILLEZ  ENTRER  UN  ID :");
                       
                       int id = sc.nextInt();
                       
                       System.out.println("  VEUILLEZ  ENTRER  UN  NOM :");
                       
                       String nom = sc.next();
                       
                       System.out.println("  VEUILLEZ  ENTRER  UN  PRENOM :");
                       
                       String prenom = sc.next();
                       
                       System.out.println("  VEUILLEZ  ENTRER  UNE  ADRESSE :");
                       
                       String adresse = sc.next();

                       System.out.println("  VEUILLEZ  ENTRER  UN  NUMERO  DE  TELEPHONE :");
                       
                       String tel = sc.next();
                       
                       System.out.println("  VEUILLEZ  ENTRER  UN  IDENTIFIANT :");
                       
                       String login = sc.next();
                       
                       System.out.println("  VEUILLEZ  ENTRER  UN  MOT  DE  PASSE :");
                       
                       String password = sc.next();
                       
                       Etudiants etudiants = new Etudiants(id, nom, prenom, adresse, tel, login, password);
                       
                       etudiantImp.addEtudiants(etudiants);
                       
                       System.out.println("    VOTRE  ETUDIANT  A  ETE  AJOUTE  AVEC  SUCCES  ");
                   break;
                   
                   case 2:
                       System.out.println("      ********  A2) SUPPRIMER UN ETUDIANT  *******   ");
                       
                       System.out.println("   VEUILLEZ  ENTRER  L'IDENTIFIANT  DE L'ETUDIANT :");
                       
                       int IdSup = sc.nextInt();
                       Etudiants etudiants2 = etudiantImp.getEtudiantsbyId(IdSup);
                       etudiantImp.deleteEtudiants(etudiants2);
                       
                       System.out.println("   ETUDIANT  SUPPRIME  ");
                   break;
                   
                   case 3:
                       System.out.println("      ********  A3) MODIFIER UN ETUDIANT   ********");
                       
                       System.out.println("    VEUILLEZ  ENTRER  L'IDENTIFIANT  DE L'ETUDIANT :");
                       
                       int IdMod = sc.nextInt();
                       Etudiants etudiants3 = etudiantImp.getEtudiantsbyId(IdMod);
                       
                       System.out.println("   VEUILLEZ  ENTRER  UN  NOM :");
                       String nomE = sc.next();
                       etudiants3.setNom(nomE);
                       
                       System.out.println("   VEUILLEZ  ENTRER  UN  PRENOM :");
                       String prenomE = sc.next();
                       etudiants3.setPrenom(prenomE);
                       
                       System.out.println("   VEUILLEZ  ENTRER  UNE  ADRESSE :");
                       String adresseE = sc.next();
                       etudiants3.setAdresse(adresseE);
                       
                       System.out.println("   VEUILLEZ  ENTRER  UN  NUMERO  DE  TELEPHONE :");
                       String telE = sc.next();
                       etudiants3.setTel(telE);
                       
                       System.out.println("    VEUILLEZ  ENTRER  UN  IDENTIFIANT :");
                       String loginE = sc.next();
                       etudiants3.setLogin(loginE);
                       
                       System.out.println("    VEUILLEZ  ENTRER  UN  MOT  DE  PASSE :");
                       String passwordE = sc.next();
                       etudiants3.setPassword(passwordE);
                       
                       etudiantImp.updateEtudiants(etudiants3);
                       
                       System.out.println("    INFORMATIONS MODIFIEES  ");
                   break;
                   
                   case 4:
                        System.out.println("    *****$***   A3)LISTE  DES  ETUDIANTS  ********  ");
                       
                       List<Etudiants> etudiant = etudiantImp.getAllEtudiants();
                       for(Etudiants etudiants4:etudiant)
                       {
                           System.out.println(etudiants4.getId()+","+etudiants4.getNom()+","+
                                   etudiants4.getPrenom()+","+etudiants4.getAdresse()+","+
                                   etudiants4.getTel()+","+etudiants4.getLogin()+","+
                                   etudiants4.getPassword());            
                       }
                   break;
                   
                   case 5:
                       System.out.println("      ********** A  BIENTOT **********   ");
                       
                       var1 = false;
                       var = true;
                   break;
                    default:
                     System.out.println("     VOTRE  CHOIX  EST INVALIDE");
                     break;
               }
            }
               break;
               
                     
            
           
           case 2:
                
                 boolean var2 = true ;
               
               while (var2) {
                
               System.out.println("         *****************     **B)GESTION DES PROFESSEURS**     ***********************"); 
               
               System.out.println("          B1) AJOUTER  UN  PROFESSEUR  ");
               System.out.println("          B2) SUPPRIMER  UN  PROFESSEUR  ");
               System.out.println("          B3) MODIFIER  UN  PROFESSEUR");
               System.out.println("          B4) AFFICHER  LA  LISTE ");
               System.out.println("          B5) RETOURNER  AU  MENU");
               
               System.out.println("      ENTREZ VOTRE CHOIX : ");
       
               int choixProfesseur  = sc.nextInt();
               switch(choixProfesseur)
               {
                   case 1:
                       
                       
                       System.out.println("     *****************    B1)AJOUTER  UN  PROFESSEUR    ************");
                       
                       System.out.println(" VEUILLEZ  ENTRER  L'IDENTIFIANT  DU  PROFESSEUR :");
                       
                       int id = sc.nextInt();
                       
                       System.out.println(" VEUILLEZ  ENTRER  UN  NOM  :");
                       
                       String nom = sc.next();
                       
                       System.out.println(" VEUILLEZ  ENTRER  UN  PRENOM :");
                       
                       String prenom = sc.next();
                       
                       System.out.println("  VEUILLEZ  ENTRER  UNE  ADRESSE :");
                       
                       String adresse = sc.next();

                       System.out.println(" VEUILLEZ  ENTRER  UN  NUMERO  DE  TELEPHONE :");
                       
                       String tel = sc.next();
                       
                       System.out.println(" VEUILLEZ  ENTRER  UN  IDENTIFIANT :");
                       
                       String login = sc.next();
                       
                       System.out.println(" VEUILLEZ  ENTRER  UN  MOT  DE  PASSE :");
                       
                       String password = sc.next();
                       
                       Professeur prof = new Professeur(id, nom, prenom, adresse, tel, login, password);
                       
                       profesImp.addProfesseur(prof);
                       
                       System.out.println("    PROFESSEUR  AJOUTE  ");
                   break;
                   
                   case 2:
                       System.out.println("     ***********   B2)SUPPRIMER  UN PROFESSEUR   ************  ");
                       
                       System.out.println(" VEUILLEZ  ENTRER  UN  IDENTIFIANT :");
                       
                       int IdSup = sc.nextInt();
                       Professeur Prof2 = profesImp.getProfesseurbyId(IdSup);
                       profesImp.deleteProfesseur(Prof2);
                       
                       System.out.println("  PROFESSEUR SUPPRIME ");
                   break;
                   
                   case 3:
                       System.out.println("      **********   B3)MODIFIER  UN  PROFESSEUR  **********");
                       
                       System.out.println(" VEUILLEZ  ENTRER  UN  IDENTIFIANT :");
                       
                       int IdMod = sc.nextInt();
                       Professeur prof3 = profesImp.getProfesseurbyId(IdMod);
                       profesImp.updateProfesseur(prof3);
                       
                       System.out.println("  PROFESSEUR MODIFIER AVEC SUCCES  ");
                   break;
                   
                   case 4:
                        System.out.println("     **********   B4)AFFICHER  LA  LISTE  **********");
                       
                       List<Professeur> profe = profesImp.getAllprofesseur();
                       for(Professeur prof4:profe)
                       {
                           System.out.println(prof4.getId()+","+prof4.getNom()+","+
                                   prof4.getPrenom()+","+prof4.getAdresse()+","+
                                   prof4.getTel()+","+prof4.getLogin()+","+
                                   prof4.getPassword());            
                       }
                   break;
                   
                   case 5:
                       System.out.println("         ************   A  BIENTOT  *************   ");
                       
                       var2 = false;
                       var = true;
                   break;
                    default:
                     System.out.println("   VOTRE  CHOIX  EST  INVALIDE  ");
                     break;
               }
            }
               
               break;
               
                          
            
           
           case 3:
                
                 boolean var3 = true ;
               
               while (var3) {
 
                
               System.out.println("              *****************      **C)GESTION DES GROUPES**     ***********************"); 
               
               System.out.println("          C1) AJOUTER  UN  GROUPE    ");
               System.out.println("          C2) SUPPRIMER  UN  GROUPE    ");
               System.out.println("          C3) MODIFIER  UN  GROUPE    ");
               System.out.println("          C4) AFFICHER  UN  GROUPE");
               System.out.println("          C5) RETOURNER  AU  MENU");
               
               System.out.println("     VEUILLEZ  ENTRER  VOTRE  CHOIX : ");
       
               int choixGroupe  = sc.nextInt();
               switch(choixGroupe)
               {
                   case 1:
                       
                       
                       System.out.println("      ***********   C1)AJOUTER  UN  GROUPE  *********** ");
                       
                       System.out.println(" VEUILLEZ  ENTRER  UN  IDENTIFIANT :");
                       
                       int id = sc.nextInt();
                       
                       System.out.println(" VEUILLEZ  ENTRER  UN  NOM  DE  GROUPE :");
                       
                       String nomGroupe = sc.next();
                       
                       System.out.println(" VEUILLEZ  ENTRER  UNE  DATE  DE  CREATION :");
                       
                       String date_creation = sc.next();
                       
                       Groupe gro = new Groupe(id, nomGroupe, date_creation);
                       groupImp.addGroupe(gro);
                       System.out.println("       GROUPE  AJOUTE AVEC SUCCES   ");
                   break;
                   
                   case 2:
                       System.out.println("       ************   C2)SUPPRIMER  UN  GROUPE   *************");
                       
                       System.out.println("  VEUILLEZ  ENTRER  UN  IDENTIFIANT :");
                       
                       int IdSup = sc.nextInt();
                       Groupe grou2 = groupImp.getGroupebyId(IdSup);
                       groupImp.deleteGroupe(grou2);
                       
                       System.out.println("      GROUPE  SUPPRIME    ");
                   break;
                   
                   case 3:
                       System.out.println("       ***********     C3)MODIFIER  UN  GROUPE  *************");
                       
                       System.out.println("  VEUILLEZ  ENTRER  UN  IDENTFIANT :");
                       
                       int IdMod = sc.nextInt();
                       Groupe grou3 = groupImp.getGroupebyId(IdMod);
                       groupImp.updateGroupe(grou3);
                       
                       System.out.println("     GROUPE  MODIFIER  AVEC  SUCCES");
                   break;
                   
                   case 4:
                
                 boolean var4 = true ;
               
               while (var4) {
                
               System.out.println("        *****************    **D)GESTION  DES  GROUPES  ETUDIANTS**    ***********************"); 
               
               System.out.println("          D1) AJOUTER  UN  GROUPE  ETUDIANT");
               System.out.println("          D2) SUPPRIMER  UN  GROUPE  ETUDIANT");
               System.out.println("          D3) MODIFIER  UN  GROUPE  ETUDIANT");
               System.out.println("          D4) AFFICHER  LA  LISTE");
               System.out.println("          D5) RETOURNER  AU  MENU");
               
               System.out.println("    VEUILLEZ  ENTRER  VOTRE  CHOIX : ");
       
               int choixgroupEtu  = sc.nextInt();
               switch(choixgroupEtu)
               {
                   case 1:
                     
                       System.out.println("    *************  D1)AJOUTER  UN  GROUPE  ETUDIANT *********** ");
                       
                       System.out.println(" VEUILLEZ  ENTRER  UN  NOM  DE  GROUPE :");
                       
                       String Nomgroupe = sc.next();
                       
                       System.out.println(" VEUILLEZ  ENTRER  UN  IDENTIFIANT :");
                       
                       int Id = sc.nextInt();
                       
                       System.out.println(" VEUILLEZ  ENTRER  UN  NOM  :");
                       
                       String nom = sc.next();
                       
                       System.out.println(" VEUILLEZ  ENTRER  UN  PRENOM :");
                       
                       String prenom = sc.next();
                       
                       System.out.println(" VEUILLEZ  ENTRER  UNE  ADRESSE :");
                       
                       String adresse = sc.next();

                       System.out.println(" VEUILLEZ  ENTRER  UN  NUMERO  DE  TELEPHONE :");
                       
                       String tel = sc.next();
                       
                       System.out.println(" VEUILLEZ  ENTRER  UN  IDENTIFIANT :");
                       
                       String login = sc.next();
                       
                       System.out.println(" VEUILLEZ  ENTRER  UN  MOT  DE  PASSE :");
                       
                       String password = sc.next();
                       
                       Studentgroup stgr = new Studentgroup(Nomgroupe, Id, nom, prenom, adresse, tel, login, password);
                       
                      studentgroupImp.addGroup(stgr);
                               
                       System.out.println(" GROUPE  ETUDIANT  AJOUTE  AVEC  SUCCES ");
                   break;
                   
                   case 2:
                       System.out.println("   **********   D2)SUPPRIMER  UN  GROUPE  ETUDIANT  *********   ");
                       
                       System.out.println(" VEUILLEZ  ENTRER  UN  IDENTFIANT :");
                       
                       int IdSu = sc.nextInt();
                       Studentgroup Grp2 = studentgroupImp.getGroupbyId(IdSu);
                       studentgroupImp.deleteGroup(Grp2);
                       
                       System.out.println("  GROUPE  ETUDIANT  SUPPRIME");
                   break;
                   
                   case 3:
                       System.out.println("     **********   D3)MODIFIER  UN  GROUPE  ETUDIANT  **********?");
                       
                       System.out.println(" VEUILLEZ  ENTRER  UN  IDENTFIANT :");
                       
                       int IdMo = sc.nextInt();
                       Studentgroup Grp3 = studentgroupImp.getGroupbyId(IdMo);
                       studentgroupImp.deleteGroup(Grp3);
                       
                       System.out.println("  GROUPE  ETUDIANT  MODIFIE  AVEC  SUCCES ");
                   break;
                   
                   case 4:
                        System.out.println("    ***********    D4)AFFICHER  LA  LISTE   ************");
                       List<Studentgroup>  grp = studentgroupImp.getAllGroup();
                       for(Studentgroup grp4:grp)
                       {
                           System.out.println(grp4.getNomgroupe()+","+grp4.getId()+","+grp4.getNom()+","+
                                   grp4.getPrenom()+","+grp4.getAdresse()+","+
                                   grp4.getTel()+","+grp4.getLogin()+","+
                                   grp4.getPassword());            
                       }
                   break;
                   
                   case 5:
                       System.out.println("     *********** A  BIENTOT ********* ");
                       
                       var4 = false;
                       var = true;
                   break;
                    default:
                     System.out.println("   VOTRE  CHOIX  EST  INVALIDE  ");
                     break;
               }
            }
               
               break;
                   
                   
                   
                   case 5:
                       System.out.println("      *********** A  BIENTOT **********");
                       
                       var4 = false;
                       var = true;
                   break;
                    default:
                     System.out.println("   VOTRE  CHOIX  EST  INVALIDE  ");
                     break;
               }
            }
               break;
               
            case 5:
               System.out.println("EXIT"); 
               System.exit(0);
               
               break;
            default:
                System.out.println("     CHOIX  INVALIDE    ");
                break;
                
       }
   } 
       }
       
}
