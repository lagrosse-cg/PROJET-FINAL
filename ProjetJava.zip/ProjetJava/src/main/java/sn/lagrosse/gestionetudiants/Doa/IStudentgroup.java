/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sn.lagrosse.gestionetudiants.Doa;

import java.util.List;
import sn.lagrosse.gestionetudiants.model.Studentgroup;


/**
 *
 * @author lenovo
 */
public interface IStudentgroup {
    
     public void addGroup(Studentgroup group);
    public void deleteGroup (Studentgroup groupEt);
    public void updateGroup(Studentgroup group);
    public Studentgroup getGroupbyId(int i);
    public List<Studentgroup> getAllGroup();
    
}
