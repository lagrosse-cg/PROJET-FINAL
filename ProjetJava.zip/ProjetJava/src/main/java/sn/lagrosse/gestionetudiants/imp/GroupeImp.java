/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sn.lagrosse.gestionetudiants.imp;

import java.util.ArrayList;
import java.util.List;
import sn.lagrosse.gestionetudiants.Doa.IGroupe;
import sn.lagrosse.gestionetudiants.model.Groupe;

/**
 *
 * @author lenovo
 */
public class GroupeImp implements IGroupe {
    
     ArrayList<Groupe> group = new ArrayList<>();
            
     @Override
    public void addGroupe(Groupe groupe) {
       group.add(groupe);
    }
    
    @Override
    public void deleteGroupe(Groupe groupe) {
        group.remove(groupe);
    }
    
    @Override
    public void updateGroupe(Groupe groupe) {
        for (Groupe groupes2:group)
       {
           if(groupes2.getId()==groupe.getId())
           {
               groupes2.setNomGroupe(groupe.getNomGroupe());
               groupes2.setDate_creation(groupe.getDate_creation());
           }
       } 
    }

    @Override
    public Groupe getGroupebyId(int i) {
        for(Groupe groupes:group)
        {
            if(groupes.getId()==i)
            {
                return groupes;
            }
        }
        return null;
    }

    @Override
    public List<Groupe> getAllGroupe() {
       return group;
    }

    
}
