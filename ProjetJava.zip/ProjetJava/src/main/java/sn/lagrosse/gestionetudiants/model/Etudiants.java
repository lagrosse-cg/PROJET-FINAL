/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sn.lagrosse.gestionetudiants.model;

/**
 *
 * @author lenovo
 */
public class Etudiants extends Personne{
    private String carte_etudiants;

    public Etudiants(int id, String nom, String prenom, String adresse, String tel, String login, String password) {
        super(id, nom, prenom, adresse, tel, login, password);
    }

    public String getCarte_etudiants() {
        return carte_etudiants;
    }

    public void setCarte_etudians(String carte_etudiants) {
        this.carte_etudiants = carte_etudiants;
    }

    @Override
    public String toString() {
        return "Etudiants{" + "carte_etudiantss=" + carte_etudiants + '}';
    } 
}
