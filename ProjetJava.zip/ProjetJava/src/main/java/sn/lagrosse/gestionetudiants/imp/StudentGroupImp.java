/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sn.lagrosse.gestionetudiants.imp;

import java.util.ArrayList;
import java.util.List;
import sn.lagrosse.gestionetudiants.Doa.IStudentgroup;
import sn.lagrosse.gestionetudiants.model.Groupe;
import sn.lagrosse.gestionetudiants.model.Studentgroup;

/**
 *
 * @author lenovo
 */
public class StudentGroupImp implements IStudentgroup{
    
    ArrayList<Studentgroup> grpE = new ArrayList<Studentgroup>();

    @Override
    public void addGroup(Studentgroup group) {
        grpE.add(group);
                
    }

    @Override
    public void deleteGroup(Studentgroup groupEt) {
        grpE.remove(groupEt);
    }

    @Override
    public void updateGroup(Studentgroup group) {
        for (Studentgroup etudiants2:grpE)
       {
           if(etudiants2.getId()==group.getId())
           {
               etudiants2.setNomgroupe(group.getNomgroupe());
               etudiants2.setNom(group.getNom());
               etudiants2.setPrenom(group.getPrenom());
               etudiants2.setLogin(group.getLogin());
               etudiants2.setPassword(group.getPassword());
               etudiants2.setAdresse(group.getAdresse());
           }
       } 
    }

    @Override
    public Studentgroup getGroupbyId(int i) {
        for(Studentgroup grpetudiants:grpE)
        {
            if(grpetudiants.getId()==i)
            {
                return grpetudiants;
            }
        }
        return null;
    }

    @Override
    public List<Studentgroup> getAllGroup() {
        return grpE;
    }

    
}
